#ifndef CREARMAZO_H
#define CREARMAZO_H
#include <vector>
#include <carta.h>

vector<Carta> crearmazo();

vector<Carta> barajeo(vector<Carta> baraja);

#endif // CREARMAZO_H
