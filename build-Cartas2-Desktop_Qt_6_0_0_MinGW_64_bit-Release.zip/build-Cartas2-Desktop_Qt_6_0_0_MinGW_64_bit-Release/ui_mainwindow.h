/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.0.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QPushButton *pushButton_oros;
    QPushButton *pushButton_copas;
    QPushButton *pushButton_espadas;
    QPushButton *pushButton_bastos;
    QPushButton *pushButton_visible1;
    QPushButton *pushButton_novisible1;
    QPushButton *pushButton_visible2;
    QPushButton *pushButton_novisible2;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QPushButton *pushButton_reglas;
    QLabel *label_estado;
    QPushButton *pushButton_ver1;
    QPushButton *pushButton_ver2;
    QPushButton *pushButton_informacion;
    QLabel *label_5;
    QLabel *label_6;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1383, 796);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/new/prefix1/imagenes/93165.ico"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        MainWindow->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 170, 0);"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        pushButton_oros = new QPushButton(centralwidget);
        pushButton_oros->setObjectName(QString::fromUtf8("pushButton_oros"));
        pushButton_oros->setGeometry(QRect(400, 40, 131, 201));
        pushButton_copas = new QPushButton(centralwidget);
        pushButton_copas->setObjectName(QString::fromUtf8("pushButton_copas"));
        pushButton_copas->setGeometry(QRect(550, 40, 131, 201));
        pushButton_espadas = new QPushButton(centralwidget);
        pushButton_espadas->setObjectName(QString::fromUtf8("pushButton_espadas"));
        pushButton_espadas->setGeometry(QRect(700, 40, 131, 201));
        pushButton_bastos = new QPushButton(centralwidget);
        pushButton_bastos->setObjectName(QString::fromUtf8("pushButton_bastos"));
        pushButton_bastos->setGeometry(QRect(850, 40, 131, 201));
        pushButton_visible1 = new QPushButton(centralwidget);
        pushButton_visible1->setObjectName(QString::fromUtf8("pushButton_visible1"));
        pushButton_visible1->setGeometry(QRect(300, 470, 131, 201));
        pushButton_novisible1 = new QPushButton(centralwidget);
        pushButton_novisible1->setObjectName(QString::fromUtf8("pushButton_novisible1"));
        pushButton_novisible1->setGeometry(QRect(140, 470, 131, 201));
        pushButton_visible2 = new QPushButton(centralwidget);
        pushButton_visible2->setObjectName(QString::fromUtf8("pushButton_visible2"));
        pushButton_visible2->setGeometry(QRect(940, 470, 131, 201));
        pushButton_novisible2 = new QPushButton(centralwidget);
        pushButton_novisible2->setObjectName(QString::fromUtf8("pushButton_novisible2"));
        pushButton_novisible2->setGeometry(QRect(1100, 470, 131, 201));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(400, 0, 131, 31));
        QFont font;
        font.setPointSize(20);
        font.setBold(true);
        label->setFont(font);
        label->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        label->setAlignment(Qt::AlignCenter);
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(550, 0, 131, 31));
        label_2->setFont(font);
        label_2->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        label_2->setAlignment(Qt::AlignCenter);
        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(700, 0, 131, 31));
        label_3->setFont(font);
        label_3->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        label_4 = new QLabel(centralwidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(850, 0, 131, 31));
        label_4->setFont(font);
        label_4->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        label_4->setAlignment(Qt::AlignCenter);
        pushButton_reglas = new QPushButton(centralwidget);
        pushButton_reglas->setObjectName(QString::fromUtf8("pushButton_reglas"));
        pushButton_reglas->setGeometry(QRect(1190, 40, 101, 41));
        pushButton_reglas->setStyleSheet(QString::fromUtf8("background-color: rgb(190, 190, 190);"));
        label_estado = new QLabel(centralwidget);
        label_estado->setObjectName(QString::fromUtf8("label_estado"));
        label_estado->setGeometry(QRect(550, 430, 281, 91));
        label_estado->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);\n"
"color: rgb(255, 255, 255);\n"
"font: 75 12pt \"MS Shell Dlg 2\";"));
        label_estado->setAlignment(Qt::AlignCenter);
        pushButton_ver1 = new QPushButton(centralwidget);
        pushButton_ver1->setObjectName(QString::fromUtf8("pushButton_ver1"));
        pushButton_ver1->setGeometry(QRect(300, 260, 131, 201));
        pushButton_ver2 = new QPushButton(centralwidget);
        pushButton_ver2->setObjectName(QString::fromUtf8("pushButton_ver2"));
        pushButton_ver2->setGeometry(QRect(940, 260, 131, 201));
        pushButton_informacion = new QPushButton(centralwidget);
        pushButton_informacion->setObjectName(QString::fromUtf8("pushButton_informacion"));
        pushButton_informacion->setGeometry(QRect(1190, 100, 101, 41));
        pushButton_informacion->setStyleSheet(QString::fromUtf8("background-color: rgb(190, 190, 190);"));
        label_5 = new QLabel(centralwidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(140, 429, 131, 31));
        QFont font1;
        font1.setPointSize(14);
        font1.setBold(true);
        label_5->setFont(font1);
        label_5->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        label_5->setAlignment(Qt::AlignCenter);
        label_6 = new QLabel(centralwidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(1100, 430, 131, 31));
        label_6->setFont(font1);
        label_6->setStyleSheet(QString::fromUtf8("color: rgb(255, 255, 255);"));
        label_6->setAlignment(Qt::AlignCenter);
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1383, 21));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "Macarra", nullptr));
        pushButton_oros->setText(QString());
        pushButton_copas->setText(QString());
        pushButton_espadas->setText(QString());
        pushButton_bastos->setText(QString());
        pushButton_visible1->setText(QString());
        pushButton_novisible1->setText(QString());
        pushButton_visible2->setText(QString());
        pushButton_novisible2->setText(QString());
        label->setText(QCoreApplication::translate("MainWindow", "OROS", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "COPAS", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "ESPADAS", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "BASTOS", nullptr));
        pushButton_reglas->setText(QCoreApplication::translate("MainWindow", "Reglas", nullptr));
        label_estado->setText(QCoreApplication::translate("MainWindow", "Es el turno del Jugador 1", nullptr));
        pushButton_ver1->setText(QString());
        pushButton_ver2->setText(QString());
        pushButton_informacion->setText(QCoreApplication::translate("MainWindow", "Informaci\303\263n", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "Jugador 1", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "Jugador 2", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
