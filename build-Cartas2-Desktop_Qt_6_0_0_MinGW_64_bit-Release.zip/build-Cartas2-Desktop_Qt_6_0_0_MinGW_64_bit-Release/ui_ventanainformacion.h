/********************************************************************************
** Form generated from reading UI file 'ventanainformacion.ui'
**
** Created by: Qt User Interface Compiler version 6.0.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VENTANAINFORMACION_H
#define UI_VENTANAINFORMACION_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_Ventanainformacion
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;

    void setupUi(QDialog *Ventanainformacion)
    {
        if (Ventanainformacion->objectName().isEmpty())
            Ventanainformacion->setObjectName(QString::fromUtf8("Ventanainformacion"));
        Ventanainformacion->resize(503, 235);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/new/prefix1/imagenes/info.ico"), QSize(), QIcon::Normal, QIcon::Off);
        Ventanainformacion->setWindowIcon(icon);
        label = new QLabel(Ventanainformacion);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(110, 80, 351, 41));
        label_2 = new QLabel(Ventanainformacion);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(110, 130, 351, 41));
        label_3 = new QLabel(Ventanainformacion);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(10, 10, 471, 61));
        QFont font;
        font.setPointSize(10);
        label_3->setFont(font);

        retranslateUi(Ventanainformacion);

        QMetaObject::connectSlotsByName(Ventanainformacion);
    } // setupUi

    void retranslateUi(QDialog *Ventanainformacion)
    {
        Ventanainformacion->setWindowTitle(QCoreApplication::translate("Ventanainformacion", "Informaci\303\263n sobre los jugadores", nullptr));
        label->setText(QString());
        label_2->setText(QString());
        label_3->setText(QCoreApplication::translate("Ventanainformacion", "Se proporciona informaci\303\263n sobre la cantidad de cartas que tiene cada jugador.", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Ventanainformacion: public Ui_Ventanainformacion {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VENTANAINFORMACION_H
