/********************************************************************************
** Form generated from reading UI file 'normas.ui'
**
** Created by: Qt User Interface Compiler version 6.0.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NORMAS_H
#define UI_NORMAS_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_Normas
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;

    void setupUi(QDialog *Normas)
    {
        if (Normas->objectName().isEmpty())
            Normas->setObjectName(QString::fromUtf8("Normas"));
        Normas->resize(1239, 608);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/new/prefix1/imagenes/rules.ico"), QSize(), QIcon::Normal, QIcon::Off);
        Normas->setWindowIcon(icon);
        Normas->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 255, 255);"));
        label = new QLabel(Normas);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 60, 571, 481));
        label_2 = new QLabel(Normas);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(630, 60, 581, 481));
        label_3 = new QLabel(Normas);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(570, 10, 81, 31));
        QFont font;
        font.setPointSize(15);
        font.setBold(true);
        label_3->setFont(font);
        label_3->setAlignment(Qt::AlignCenter);

        retranslateUi(Normas);

        QMetaObject::connectSlotsByName(Normas);
    } // setupUi

    void retranslateUi(QDialog *Normas)
    {
        Normas->setWindowTitle(QCoreApplication::translate("Normas", "Reglas del macarra", nullptr));
        label->setText(QString());
        label_2->setText(QString());
        label_3->setText(QCoreApplication::translate("Normas", "Reglas", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Normas: public Ui_Normas {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NORMAS_H
